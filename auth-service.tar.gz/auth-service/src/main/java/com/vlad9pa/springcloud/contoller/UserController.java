package com.vlad9pa.springcloud.contoller;

import com.fasterxml.jackson.databind.JsonNode;
import com.vlad9pa.springcloud.entity.User;
import com.vlad9pa.springcloud.service.SecurityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

/**
 * @author Vlad Milyutin.
 */
@RestController
public class UserController {

    private final UserDetailsService userDetailsService;

    private final SecurityService securityService;

    @Autowired
    public UserController(UserDetailsService userDetailsService, SecurityService securityService) {
        this.userDetailsService = userDetailsService;
        this.securityService = securityService;
    }

    @PostMapping(value = "/auth", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    User auth(@RequestParam("username") String username,
              @RequestParam("password") String password){

        securityService.autoLogin(username,password);

        User user = securityService.findLoggedInUser();

        System.out.println("USER:::POST:::"+user.toString());

        return user;

    }

    @GetMapping(value = "/auth", produces = MediaType.APPLICATION_JSON_VALUE)
    User authGet(){
        return securityService.findLoggedInUser();

    }

}
