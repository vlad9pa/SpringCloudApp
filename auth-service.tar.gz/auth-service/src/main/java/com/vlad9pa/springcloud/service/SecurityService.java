package com.vlad9pa.springcloud.service;

import com.vlad9pa.springcloud.entity.User;

/**
 * @author Vlad Milyutin.
 */
public interface SecurityService {
    User findLoggedInUser();
    void autoLogin(String userName, String password);
}
